/*
 * Copyright 2013, Google LLC
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google LLC nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.android.tools.smali.dexlib2.analysis.reflection;

import com.android.tools.smali.dexlib2.analysis.reflection.util.ReflectionUtils;
import com.android.tools.smali.dexlib2.base.reference.BaseTypeReference;
import com.android.tools.smali.dexlib2.iface.Annotation;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.Field;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.util.ChainedIterator;
import com.android.tools.smali.util.IteratorUtils;
import com.android.tools.smali.util.TransformedIterator;
import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import com.google.common.base.Function;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * Wraps a ClassDef around a class loaded in the current VM
 *
 * Only supports the basic information exposed by ClassProto
 */
public class ReflectionClassDef extends BaseTypeReference implements ClassDef {
    private final Class cls;

    public ReflectionClassDef(Class cls) {
        this.cls = cls;
    }

    @Override public int getAccessFlags() {
        // the java modifiers appear to be the same as the dex access flags
        return cls.getModifiers();
    }

    @Nullable @Override public String getSuperclass() {
        if (Modifier.isInterface(cls.getModifiers())) {
            return "Ljava/lang/Object;";
        }
        Class superClass = cls.getSuperclass();
        if (superClass == null) {
            return null;
        }
        return ReflectionUtils.javaToDexName(superClass.getName());
    }

    @Nonnull @Override public List<String> getInterfaces() {
		Class<?>[] interfaces = cls.getInterfaces();
		List<String> interfaceNames = new ArrayList<>();
		for (Class<?> iface : interfaces) {
			if (iface == null) {
				interfaceNames.add(null);
			} else {
				interfaceNames.add(ReflectionUtils.javaToDexName(iface.getName()));
			}
		}
		return interfaceNames;
	}

    @Nullable @Override public String getSourceFile() {
        return null;
    }

    @Nonnull @Override public Set<? extends Annotation> getAnnotations() {
        return Collections.emptySet();
    }

    @Nonnull @Override public Iterable<? extends Field> getStaticFields() {
        return new Iterable<>() {
            @Nonnull
            @Override
            public Iterator<Field> iterator() {
                Iterator<java.lang.reflect.Field> staticFields = IteratorUtils.filter(
                        Arrays.asList(cls.getDeclaredFields()),
                        input -> input != null && Modifier.isStatic(input.getModifiers()));

                return new TransformedIterator<>(staticFields, new Function<>() {
                    @Nullable
                    @Override
                    public Field apply(@Nullable java.lang.reflect.Field input) {
                        return new ReflectionField(input);
                    }
                });
            }
        };
    }

    @Nonnull @Override public Iterable<? extends Field> getInstanceFields() {
        return new Iterable<>() {
            @Nonnull
            @Override
            public Iterator<Field> iterator() {
                Iterator<java.lang.reflect.Field> staticFields = IteratorUtils.filter(
                        Arrays.asList(cls.getDeclaredFields()),
                        input -> input != null && !Modifier.isStatic(input.getModifiers()));

                return new TransformedIterator<>(staticFields,
                        new Function<>() {
                            @Nullable
                            @Override
                            public Field apply(@Nullable java.lang.reflect.Field input) {
                                return new ReflectionField(input);
                            }
                        }
                );
            }
        };
    }

    @Nonnull @Override public Set<? extends Field> getFields() {
        return new AbstractSet<>() {
            @Nonnull
            @Override
            public Iterator<Field> iterator() {
                return new TransformedIterator<>(
                        Arrays.asList(cls.getDeclaredFields()),
                        new Function<>() {
                            @Nullable
                            @Override
                            public Field apply(@Nullable java.lang.reflect.Field input) {
                                return new ReflectionField(input);
                            }
                        });
            }

            @Override
            public int size() {
                return cls.getDeclaredFields().length;
            }
        };
    }

    private static final int DIRECT_MODIFIERS = Modifier.PRIVATE | Modifier.STATIC;
    @Nonnull @Override public Iterable<? extends Method> getDirectMethods() {
        return new Iterable<>() {
            @Nonnull
            @Override
            public Iterator<Method> iterator() {
                Iterator<Method> constructorIterator =
                        new TransformedIterator<>(
                                Arrays.asList(cls.getDeclaredConstructors()).iterator(),
                                new Function<>() {
                                    @Nullable
                                    @Override
                                    public Method apply(@Nullable Constructor input) {
                                        return new ReflectionConstructor(input);
                                    }
                                });

                Iterator<java.lang.reflect.Method> directMethods = IteratorUtils.filter(
                        Arrays.asList(cls.getDeclaredMethods()),
                        input -> input != null && (input.getModifiers() & DIRECT_MODIFIERS) != 0);

                Iterator<Method> methodIterator = new TransformedIterator<>(
                        directMethods,
                        new Function<>() {
                            @Nullable
                            @Override
                            public Method apply(@Nullable java.lang.reflect.Method input) {
                                return new ReflectionMethod(input);
                            }
                        });
                return new ChainedIterator<>(constructorIterator, methodIterator);
            }
        };
    }

    @Nonnull @Override public Iterable<? extends Method> getVirtualMethods() {
        return new Iterable<>() {
            @Nonnull
            @Override
            public Iterator<Method> iterator() {
                Iterator<java.lang.reflect.Method> directMethods = IteratorUtils.filter(
                        Arrays.asList(cls.getDeclaredMethods()),
                        input -> input != null && (input.getModifiers() & DIRECT_MODIFIERS) == 0);

                return new TransformedIterator<>(directMethods,
                        new Function<>() {
                            @Nullable
                            @Override
                            public Method apply(@Nullable java.lang.reflect.Method input) {
                                return new ReflectionMethod(input);
                            }
                        });
            }
        };
    }

    @Nonnull @Override public Set<? extends Method> getMethods() {
        return new AbstractSet<>() {
            @Nonnull
            @Override
            public Iterator<Method> iterator() {
                Iterator<Method> constructorIterator =
                        new TransformedIterator<>(
                                Arrays.asList(cls.getDeclaredConstructors()),
                                new Function<>() {
                                    @Nullable
                                    @Override
                                    public Method apply(@Nullable Constructor input) {
                                        return new ReflectionConstructor(input);
                                    }
                                });

                Iterator<Method> methodIterator =
                        new TransformedIterator<>(
                                Arrays.asList(cls.getDeclaredMethods()),
                                new Function<>() {
                                    @Nullable
                                    @Override
                                    public Method apply(@Nullable java.lang.reflect.Method input) {
                                        return new ReflectionMethod(input);
                                    }
                                });
                return new ChainedIterator<>(constructorIterator, methodIterator);
            }

            @Override
            public int size() {
                return cls.getDeclaredMethods().length + cls.getDeclaredConstructors().length;
            }
        };
    }

    @Nonnull @Override public String getType() {
        return ReflectionUtils.javaToDexName(cls.getName());
    }
}
